<div class="error-msg alert alert-danger" style="display: none;">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
    <strong>Required Fields</strong>
    <hr class="message-inner-separator">    
    <div class="error_list"></div>
</div>