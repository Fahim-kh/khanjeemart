<!-- <div class="form-group row">
    <label for="status" class="col-md-12 col-form-label">Status</label>
    <div class="col-md-12">
        <label class="custom-switch pl-0" id="toggleForm" style="margin-top: 5px;">
            <input type="checkbox" name="status" id="check_uncheck" class="custom-switch-input">
            <span class="custom-switch-indicator"></span>
            <span class="custom-switch-description" id="statusText">OFF</span>
        </label>
    </div>
</div> -->

<div class="form-switch switch-primary d-flex align-items-center gap-2">
                                <input class="form-check-input" type="checkbox" role="switch" name="status" id="switch1" checked="">
                                <label class="form-check-label line-height-1 fw-medium text-secondary-light" for="switch1"> Active</label>
                            </div>

                            